package exceptions;

public class InvalidNameException extends Exception {
	private static final long serialVersionUID = -69637829093235855L;
}
